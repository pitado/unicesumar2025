package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
            ShoppingCart shoppingCart = new ShoppingCart();
            Item i = new Item();
            i.setDesc("xbox");
            i.setPrice(250.0);
            String option = "bitcoin";
            if (option.equals("invoice")){
                InvoiceStrategy invoice = new InvoiceStrategy();
                shoppingCart.pay(invoice);
            } else if (option.equals("card")) {
                CardStrategy card = new CardStrategy();
                shoppingCart.pay(card);
            } else if(option.equals("bitcoin")){
                shoppingCart.pay(new BitcoinStrategy());
            }
        }
    }