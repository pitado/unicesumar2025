package org.example;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<Item> itemList = new ArrayList<>();

    public void addItem(Item item){
        this.itemList.add(item);
    }

    public void removeItem(Item item){
        this.itemList.remove(item);
    }

    public Double calculaTotal(){
        Double total = 0.0;
        for(Item item : itemList){
            total += item.getPrice();
        }

        return total;
    }


    // implementar varias forma de pagamento
    public void pay(PaymentStrategy strategy){
        strategy.pay(this.calculaTotal());
    }
}
