package org.example;

public interface PaymentStrategy {
    public void pay(Double valor);
}
