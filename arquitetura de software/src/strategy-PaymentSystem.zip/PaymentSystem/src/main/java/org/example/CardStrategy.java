package org.example;

public class CardStrategy implements PaymentStrategy{
    private String cardNumber;
    private Boolean valid;
    private Integer n_installments;

    private void validateCard(String cardNumber){
        System.out.println(this.cardNumber);
    }

    @Override
    public void pay(Double valor){
        System.out.println("Paying by card.");
    }
}
