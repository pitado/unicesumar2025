package org.example;

public class InvoiceStrategy implements PaymentStrategy{
    private String barcode;

    private void generateBarcode(Double valor){
        System.out.println(this.barcode);
    }

    @Override
    public void pay(Double valor){
        System.out.println("Paying by invoice.");
    }
}
