import java.util.HashMap;
import java.util.List;

public interface CSVReader {
    public List<HashMap> getCsv(String csvUrl);
}
