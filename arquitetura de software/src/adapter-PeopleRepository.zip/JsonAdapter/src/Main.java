public class Main {

    public static void main(String[] args) {
        String csvURL = ".\\repo\\file.csv";

        PersonCSVAdapter personCSVAdapter = new PersonCSVAdapter(csvURL);

        for(Person p:personCSVAdapter.listPeople()){
            System.out.println(p.getName() + " " + p.getAge());
        }
    }
}
