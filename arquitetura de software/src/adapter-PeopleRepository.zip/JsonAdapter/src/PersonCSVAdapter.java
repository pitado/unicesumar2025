import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PersonCSVAdapter implements PeopleRepository, CSVReader{
    private String csvUrl;
    public PersonCSVAdapter(String csvUrl) {
        this.csvUrl = csvUrl;
    }

    @Override
    public List<Person> listPeople() {
        List<Person> people = new ArrayList<>();
        for(HashMap<String, String> p : this.getCsv(this.csvUrl)) {
            people.add(new Person(p.get("name"),
                                  p.get("email"),
                                  Integer.parseInt(p.get("age"))));
        }

        return people;
    }

    @Override
    public List<HashMap> getCsv(String csvUrl) {
        List<HashMap> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(this.csvUrl))) {
            String line;
            String[] header = reader.readLine().split(",");

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                HashMap<String,String> info = new HashMap<String,String>();
                info.put("name", data[0]);
                info.put("age", data[1]);
                info.put("email", data[2]);
                lines.add(info);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }
}
