import java.util.List;

public interface PeopleRepository {
    public List<Person> listPeople();
}
