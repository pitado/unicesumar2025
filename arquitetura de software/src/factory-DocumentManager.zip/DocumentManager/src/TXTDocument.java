public class TXTDocument implements Document{
    private String defaultText = "Hello World";
    @Override
    public String read() {
        return defaultText;
    }
}
