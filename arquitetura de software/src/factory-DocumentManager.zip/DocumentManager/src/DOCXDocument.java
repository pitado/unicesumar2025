public class DOCXDocument implements Document{
    @Override
    public String read() {
        return "Isso é um DOCX";
    }
}
