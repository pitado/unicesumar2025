public interface Document {
    public String read(); // retorne o tipo de documento
}
