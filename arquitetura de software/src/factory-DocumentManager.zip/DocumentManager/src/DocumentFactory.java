public abstract class DocumentFactory {

    public static Document createDocument(String type){
        Document document = null;
        if(type.equals("PDF")){
            document = new PDFDocument();
        } else if (type.equals("JSON")){
            document = new JSONDocument();
        } else if (type.equals("TXT")){
            document = new TXTDocument();
        } else if (type.equals("DOCX")){
            document = new DOCXDocument();
        }
        return document;
    }
}
