public class PDFDocument implements Document{
    @Override
    public String read() {
        return "Isso eh um PDF.";
    }
}
