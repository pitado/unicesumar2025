public class JSONDocument implements Document{
    @Override
    public String read() {
        return "Isso eh um JSON.";
    }
}
