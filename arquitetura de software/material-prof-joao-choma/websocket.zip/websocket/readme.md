npm init -y

npm install ws

node server.js

node client.js