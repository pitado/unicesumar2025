export class VendedorDTO {
    constructor({ nome, email, telefone }) {
      this.nome = nome;
      this.email = email;
      this.telefone = telefone;
    }
  }
  