npm init -y

npm install nodemailer

node sendEmail.js