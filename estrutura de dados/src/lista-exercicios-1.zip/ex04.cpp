//5. Crie um vetor de n inteiros alocados dinamicamente. 
// Utilize a fun��o rand() para preencher o vetor.  
// Apresente a soma de seus elementos.

#include<stdio.h>
#include<stdlib.h>
#include<time.h>


int main(void){
	int *vetor;
	int tamanho;
	int soma;
	
	printf("Informe o tamanho do vetor: ");
	scanf("%d", &tamanho);
	
	vetor = (int*) malloc(tamanho * sizeof(int));
	//mais eficiente
	for(int i = 0; i < tamanho; i++){
		vetor[i] = rand() % 100;
	}
	
	// mais legivel
	for(int i = 0; i < tamanho; i++){
		soma += vetor[i];
	}
	
	for(int i = 0; i < tamanho; i++){
		printf("\nO %do numero eh %d", i, vetor[i]);
	}
	
	printf("\nA soma eh: %d", soma);
	
	
}


