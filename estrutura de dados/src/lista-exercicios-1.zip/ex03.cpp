//4.	Aloque dinamicamente um vetor de 10 inteiros 
// e preencha-o com os quadrados dos �ndices (0, 1, 4, 9, �).

#include<stdio.h>
#include<stdlib.h>


int main(void){
	int *vetor;
	int tamanho = 12;
	
	vetor = (int*) malloc(tamanho * sizeof(int));
	
	for(int i = 0; i < tamanho; i++){
		vetor[i] = i * i;
	}
	
	for(int i = 0; i < tamanho; i++){
		printf("\nO %do numero eh %d", i, vetor[i]);
	}
	
	
}


