//6.	Aloque dinamicamente um vetor cujo tamanho � 
// definido pelo usu�rio e permita que ele preencha os valores. 
// Depois, conte quantos n�meros pares foram informados pelo usu�rio;

#include<stdio.h>
#include<stdlib.h>
#include<time.h>


int main(void){
	int *vetor;
	int tamanho;
	int pares;
	
	printf("Informe o tamanho do vetor: ");
	scanf("%d", &tamanho);
	
	vetor = (int*) malloc(tamanho * sizeof(int));
	
	//mais eficiente
	for(int i = 0; i < tamanho; i++){
		printf("Informe um vetor: ");
		scanf("%d", vetor[i]);
	}
	
	// mais legivel
	for(int i = 0; i < tamanho; i++){
		if(vetor[i] % 2 == 0){
			pares++;
		}

	}
	
	for(int i = 0; i < tamanho; i++){
		printf("\nO %do numero eh %d", i, vetor[i]);
	}
	
	printf("\nOs inteiros sao: %d", pares);
	
	
}


