// 3. Utilizando aloca��o din�mica, crie duas vari�veis inteiras 
// e uma vari�vel do tipo float. 
// Pe�a que o usu�rio informe um dividendo e um divisor. 
// Divida os n�meros informados, salvando o resultado na vari�vel float. 
// Imprima o resultado da divis�o.

#include<stdio.h>
#include<stdlib.h>


int main(void){
	// definir as variaveis
	// numeros que serao informados
	int *dividendo, *divisor;
	
	// resultado da divisao
	float *resultado;
	
	// alocando memoria para a variavel dividendo
	// a quantidade de memoria em BYTES
	// � igual ao tamanho de um inteiro
	// usamos (int*) para converter (informando) o programa
	// que um dado do tipo inteiro vai ser salvo
	// na memoria alocada
	dividendo = (int*) malloc(sizeof(int));
	divisor = (int*) malloc(sizeof(int));
	
	// alocando memoria para a variavel resultado
	// a quantidade de memoria em BYTES
	// � igual ao tamanho de um float,
	// usamos (float*) para converter (informando) o programa
	// que um dado do tipo float vai ser salvo
	// na memoria alocada	
	resultado = (float*) malloc(sizeof(float));
	
	
	// pedindo um valor
	printf("Informe o dividendo: ");
	
	// lendo o valor
	// nao usamos & pq o ponteiro dividendo ja eh um endereco
	// a funcao scanf espera um endereco como parametro
	scanf("%d", dividendo);
	
	// pedindo um valor
	printf("\nInforme o divisor: ");
	
	// lendo o valor
	// nao usamos & pq o ponteiro dividendo ja eh um endereco
	// a funcao scanf espera um endereco como parametro
	scanf("%d", divisor);
	
	// dividindo dois inteiros e salvando em resultado
	// usa os asteriscos para acessar o conteudo da variavel
	*resultado = *dividendo / *divisor;
	
	// apresenta o valor
	printf("/nO resultado eh %.2f", *resultado);
}


