// 2.	Aloque dinamicamente um vetor cujo tamanho � definido pelo usu�rio 
// e permita que ele preencha os valores. E apresente os valores;


// 1. definir a variavel vetor
// 2. pedir o tamanho para o usuario
// 3. alocar a memoria
// 4. ler os valores digitados pelo usuario
// 5. apresentar os valores

#include<stdio.h>
#include<stdlib.h>


int main(void){
	
	// definir o vetor
	int *vetor, tamanho; 
	
	printf("\n Digite o tamanho do vetor: ");
	scanf("%d", &tamanho);
	
	vetor = (int*) malloc(tamanho * sizeof(int));
	
	for(int i = 0; i < tamanho; i++){
		printf("\n Digite o %do numero: ", i+1);
		//scanf("%d", vetor[i]);
		scanf("%d", (vetor+i));
	}
	
	for (int i=0; i<tamanho; i++){
		printf("\n O %do numero eh %d ", i+1, *(vetor+i));
	}
	
	
	
	
}


