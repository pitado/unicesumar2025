import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception{

        System.out.println(Singleton.getInstance().value);
    }
}
